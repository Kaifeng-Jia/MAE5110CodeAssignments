"""Check rimless-wheel dynamics, impacts, rolling, and standing."""

import numpy as np
from models import rimless_wheel as model
from simulate_wheel import simulate_continuous_step, simulate_wheel


def check_continuous_dynamics(parameters):
    """Check two known state derivatives."""
    np.testing.assert_allclose(
        model.calculate_state_derivative(0.0, np.array([0.0, 2.0]), parameters),
        [2.0, 0.0],
        atol=1e-12,
    )
    np.testing.assert_allclose(
        model.calculate_state_derivative(0.0, np.array([np.pi / 6, 0.0]), parameters),
        [0.0, 4.905],
        atol=1e-12,
    )


def check_continuous_step(parameters):
    """Check contact speed, timestep convergence, and energy conservation."""
    step_start_angle, step_end_angle = model.calculate_contact_angles(parameters)
    initial_angular_velocity = 2.0
    initial_state = np.array([step_start_angle, initial_angular_velocity])
    expected_velocity = np.sqrt(
        initial_angular_velocity**2
        + 2
        * parameters["gravity"]
        / parameters["spoke_length"]
        * (np.cos(step_start_angle) - np.cos(step_end_angle))
    )
    velocity_errors = []
    for time_step in (0.02, 0.01, 0.005):
        _, states, reason = simulate_continuous_step(
            initial_state, parameters, time_step
        )
        assert reason == "contact"
        velocity_errors.append(abs(states[1, -1] - expected_velocity))

    assert velocity_errors[0] > velocity_errors[1] > velocity_errors[2]
    np.testing.assert_allclose(states[1, -1], expected_velocity, rtol=0, atol=1e-8)
    np.testing.assert_allclose(states[0, -1], step_end_angle, rtol=0, atol=1e-12)
    kinetic_energy, potential_energy = model.calculate_energy(states, parameters)
    total_energy = kinetic_energy + potential_energy
    np.testing.assert_allclose(total_energy, total_energy[0], rtol=0, atol=1e-8)


def check_impact(parameters):
    """Check impact geometry and energy changes."""
    slope_angle = parameters["slope_angle"]
    spoke_length = parameters["spoke_length"]
    half_spoke_angle = np.pi / parameters["spoke_count"]
    for direction in (-1, 1):
        contact_angle = slope_angle + direction * half_spoke_angle
        state_before_contact = np.array([contact_angle, direction * 2.0])
        assert model.detect_contact(state_before_contact, parameters)
        state_after_contact = model.reset_after_contact(state_before_contact, parameters)
        assert not model.detect_contact(state_after_contact, parameters)
        np.testing.assert_allclose(
            state_after_contact[0], slope_angle - direction * half_spoke_angle
        )
        np.testing.assert_allclose(state_after_contact[1], direction * np.sqrt(2))

        # Reconstruct the hub position after changing the support foot.
        new_contact_position = (
            direction
            * 2
            * spoke_length
            * np.sin(half_spoke_angle)
            * np.array([np.cos(slope_angle), -np.sin(slope_angle)])
        )
        hub_before = spoke_length * np.array(
            [np.sin(contact_angle), np.cos(contact_angle)]
        )
        angle_after = state_after_contact[0]
        hub_after = new_contact_position + spoke_length * np.array(
            [np.sin(angle_after), np.cos(angle_after)]
        )
        np.testing.assert_allclose(hub_after, hub_before, atol=1e-12)

        kinetic_before, potential_before = model.calculate_energy(
            state_before_contact, parameters
        )
        kinetic_after, potential_after = model.calculate_energy(
            state_after_contact, parameters, contact_height=new_contact_position[1]
        )
        np.testing.assert_allclose(kinetic_after, kinetic_before / 2)
        np.testing.assert_allclose(potential_after, potential_before)


def check_repeated_steps(parameters):
    """Check impact timing, resets, and energy gain over five steps."""
    initial_angular_velocity = 2.0
    step_start_angle, step_end_angle = model.calculate_contact_angles(parameters)
    initial_state = [step_start_angle, initial_angular_velocity]
    times, states, reason = simulate_wheel(initial_state, parameters, 5)
    assert reason == "step_limit"
    impact_indices = np.flatnonzero(np.diff(times) == 0)
    assert len(impact_indices) == 5
    assert np.all(np.diff(times) >= 0)
    assert impact_indices[-1] == len(times) - 2

    before_contact = states[:, impact_indices]
    after_contact = states[:, impact_indices + 1]
    np.testing.assert_allclose(before_contact[0], step_end_angle, rtol=0, atol=1e-12)
    np.testing.assert_allclose(after_contact[0], step_start_angle, rtol=0, atol=1e-12)
    np.testing.assert_allclose(
        after_contact[1],
        before_contact[1] * np.cos(2 * np.pi / parameters["spoke_count"]),
    )

    step_start_velocities = np.concatenate(
        ([initial_angular_velocity], after_contact[1, :-1])
    )
    expected_squared_velocities = step_start_velocities**2 + 2 * parameters[
        "gravity"
    ] / parameters["spoke_length"] * (np.cos(step_start_angle) - np.cos(step_end_angle))
    np.testing.assert_allclose(
        before_contact[1] ** 2, expected_squared_velocities, rtol=0, atol=1e-7
    )


def check_rocking_and_standing(parameters):
    """Check alternating impacts and decay toward standing."""
    step_start_angle, _ = model.calculate_contact_angles(parameters)
    times, states, reason = simulate_wheel([step_start_angle, 0.1], parameters)
    impact_indices = np.flatnonzero(np.diff(times) == 0)
    before_contact = states[:, impact_indices]
    after_contact = states[:, impact_indices + 1]

    assert reason == "standing"
    assert before_contact[1, 0] < 0
    assert np.all(np.diff(times[impact_indices]) > 0)
    assert np.all(after_contact[1, 1:] * after_contact[1, :-1] < 0)
    assert np.all(np.diff(np.abs(after_contact[1])) < 0)
    np.testing.assert_allclose(before_contact[1, 0], -0.1, rtol=0, atol=1e-8)
    np.testing.assert_allclose(
        before_contact[1, 1:], -after_contact[1, :-1], rtol=1e-4, atol=1e-9
    )
    assert not model.detect_standing([0.0, 0.0], parameters, 1e-4)


def main():
    parameters = model.create_parameters()
    check_continuous_dynamics(parameters)
    check_continuous_step(parameters)
    check_impact(parameters)
    check_repeated_steps(parameters)
    check_rocking_and_standing(parameters)
    print("All model checks passed.")


if __name__ == "__main__":
    main()
